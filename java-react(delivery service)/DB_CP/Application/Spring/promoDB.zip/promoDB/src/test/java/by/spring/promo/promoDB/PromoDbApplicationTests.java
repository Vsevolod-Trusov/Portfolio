package by.spring.promo.promoDB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PromoDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
