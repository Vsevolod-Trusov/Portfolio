package by.spring.promo.promoDB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PromoDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(PromoDbApplication.class, args);
	}

}
